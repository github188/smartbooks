﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace 图书销售管理系统
{
    class InPutOnly
    {
        /// <summary>
        /// 只接受数字和退格键
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void TextOnlyNum(object sender, KeyPressEventArgs e)
        {
            //只接受数字和退格键
            if (e.KeyChar.CompareTo('0') < 0 || e.KeyChar.CompareTo('9') > 0)
            {
                //输入的不是数字或退格键，则输入的字不会放到文本框中
                if (e.KeyChar != '\b')
                    e.Handled = true;
            }
        }
    }
}
