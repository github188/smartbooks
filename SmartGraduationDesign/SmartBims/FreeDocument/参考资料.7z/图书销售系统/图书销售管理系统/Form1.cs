﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int i=0;
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtusers.Text == "")
            {
                MessageBox.Show("操作员账号不能为空");
                return;
            }
           
            if (i < 2)
            {
                //新建连接
                SqlConnection MyConnection = DB.CreateConnection();
                //打开连接
                MyConnection.Open();
                //新建命令
                SqlCommand cmd = new SqlCommand("select count(*) from operator where 账号='" + txtusers.Text + "' and 密码='" + txtpwd.Text + "' ", MyConnection);
                SqlCommand cmd1 = new SqlCommand("select count(*) from operator where 账号='" + txtusers.Text + "' and 密码='" + txtpwd.Text + "'and 是否注销=1", MyConnection);
               
                int count = Convert.ToInt16(cmd.ExecuteScalar());
                int count1 = Convert.ToInt16(cmd1.ExecuteScalar());
               
                if (count1 >0)
                {
                    MessageBox.Show("该用户名已被注销,如需登陆请跟管理员联系");
                    txtusers.Text = "";
                    txtpwd.Text = "";
                    txtusers.Focus();
                    i = i + 1;
                }
              
                else if (count > 0)
                {
                    this.DialogResult = DialogResult.OK;
                    show.caozuo = txtusers.Text;
                }
                else if (txtusers.Text == "admin" && txtpwd.Text == "bsd")
                {
                    this.DialogResult = DialogResult.OK;
                    show.caozuo = txtusers.Text;
                }
                else
                {
                    MessageBox.Show("用户名或密码输入错误,登录失败");

                    txtpwd.Text = "";
                    txtpwd.Focus();
                    i = i + 1;
                }
                MyConnection.Close();
                MyConnection.Dispose();
                cmd.Dispose();
                cmd1.Dispose();
            }
           else
            {
                MessageBox.Show("用户名或密码输入错误超过三次,系统将自动退出");
                Application.Exit();
            }
        }

        private void btncancle_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}