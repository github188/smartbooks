﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;
using System.Configuration;

namespace 图书销售管理系统
{
    class DB
    {
        #region 建立数据库的连接
        ///<summary> 
        ///建立数据库的连接
        ///<summary/>
        ///<return>返回sqlconnection对象<return/>
        public static SqlConnection CreateConnection()
        {
            string str = ConfigurationSettings.AppSettings["ConnectionString"].ToString();
            SqlConnection MyConnection = new SqlConnection(str);
            return MyConnection;
        }
        #endregion


        #region 执行sqlcommand命令
        ///<summary/>
        ///执行sqlcommand命令
        ///<summary/>
        ///<param name="strCommand">要执行的SQL语句</param>
        public static void ExecCommand(string strSql)
        {
            SqlConnection MyConnection = DB.CreateConnection();
            MyConnection.Open();
            SqlCommand MyCommand = new SqlCommand(strSql, MyConnection);
            MyCommand.ExecuteNonQuery();
            MyCommand.Dispose();
            MyConnection.Close();
            MyConnection.Dispose();
        }
        #endregion

        #region 创建DataSet对象
        ///<summary/>
        ///创建DataSet对象
        ///<param name="strTable">表名</param>
        ///<param name="strSql">Sql语句</param>
        ///<return>返回对象<return/>
        public DataSet GetDataSet(string strSql, string strTable)
        {
            SqlConnection MyConnection = DB.CreateConnection();
            SqlDataAdapter MyAdapter = new SqlDataAdapter(strSql, MyConnection);
            DataSet MyDataSet = new DataSet();
            MyAdapter.Fill(MyDataSet, strTable);
            return MyDataSet;
        }
        #endregion

        #region 绑定 ComboBox控件
        ///<summary>
        ///绑定 ComboBox控件
        ///<summary>
        ///<param name="strSql">Sql语句</param>
        ///<param name="strTable">表名</param>
        ///<param name="strMember">要显示数据库中表的字段</param>
        ///<param name="strValue">实际存储中数据库中表的字段</param>
        ///<param name="cmb">要绑定的ComboBox控件</param>
        public static void Combind(string strSql, string strTable, string strMember, string strValue, ComboBox cmb)
        {
            SqlConnection MyConnection = DB.CreateConnection();
            DB MyDb = new DB();
            DataSet MyDataSet = MyDb.GetDataSet(strSql, strTable);
            cmb.DataSource = MyDataSet.Tables[strTable];
            cmb.DisplayMember = strMember;
            cmb.ValueMember = strValue;

        }
        #endregion
     
      
           
        
    }
}
