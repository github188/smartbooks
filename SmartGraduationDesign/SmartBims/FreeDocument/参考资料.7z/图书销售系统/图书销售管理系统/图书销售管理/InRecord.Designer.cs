﻿namespace 图书销售管理系统.图书销售管理
{
    partial class InRecord
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InRecord));
            this.dgvInRecord = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radbookname = new System.Windows.Forms.RadioButton();
            this.radbooknum = new System.Windows.Forms.RadioButton();
            this.btnfetch = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRefersh = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.dTPTime = new System.Windows.Forms.DateTimePicker();
            this.txtInRecordPrice = new System.Windows.Forms.TextBox();
            this.txtSalePrice = new System.Windows.Forms.TextBox();
            this.txtBookCount = new System.Windows.Forms.TextBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.txtBookID = new System.Windows.Forms.TextBox();
            this.txtzhanghao = new System.Windows.Forms.TextBox();
            this.txtWaterID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInRecord)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvInRecord
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInRecord.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvInRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvInRecord.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvInRecord.Location = new System.Drawing.Point(12, 0);
            this.dgvInRecord.Name = "dgvInRecord";
            this.dgvInRecord.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInRecord.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvInRecord.RowTemplate.Height = 23;
            this.dgvInRecord.Size = new System.Drawing.Size(491, 201);
            this.dgvInRecord.TabIndex = 0;
            this.dgvInRecord.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInRecord_CellClick);

            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.btnClose);
            this.groupBox1.Controls.Add(this.btnRefersh);
            this.groupBox1.Controls.Add(this.btnCancle);
            this.groupBox1.Controls.Add(this.btnsave);
            this.groupBox1.Controls.Add(this.btnadd);
            this.groupBox1.Controls.Add(this.dTPTime);
            this.groupBox1.Controls.Add(this.txtInRecordPrice);
            this.groupBox1.Controls.Add(this.txtSalePrice);
            this.groupBox1.Controls.Add(this.txtBookCount);
            this.groupBox1.Controls.Add(this.txtBookName);
            this.groupBox1.Controls.Add(this.txtBookID);
            this.groupBox1.Controls.Add(this.txtzhanghao);
            this.groupBox1.Controls.Add(this.txtWaterID);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.Color.Teal;
            this.groupBox1.Location = new System.Drawing.Point(13, 203);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(490, 209);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "入库操作";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.radbookname);
            this.groupBox2.Controls.Add(this.radbooknum);
            this.groupBox2.Controls.Add(this.btnfetch);
            this.groupBox2.ForeColor = System.Drawing.Color.Teal;
            this.groupBox2.Location = new System.Drawing.Point(304, 114);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(174, 84);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "查找";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(7, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(78, 21);
            this.textBox1.TabIndex = 2;
            // 
            // radbookname
            // 
            this.radbookname.AutoSize = true;
            this.radbookname.ForeColor = System.Drawing.Color.Black;
            this.radbookname.Location = new System.Drawing.Point(109, 18);
            this.radbookname.Name = "radbookname";
            this.radbookname.Size = new System.Drawing.Size(47, 16);
            this.radbookname.TabIndex = 1;
            this.radbookname.TabStop = true;
            this.radbookname.Text = "书名";
            this.radbookname.UseVisualStyleBackColor = true;
            this.radbookname.CheckedChanged += new System.EventHandler(this.radbookname_CheckedChanged);
            // 
            // radbooknum
            // 
            this.radbooknum.AutoSize = true;
            this.radbooknum.ForeColor = System.Drawing.Color.Black;
            this.radbooknum.Location = new System.Drawing.Point(7, 18);
            this.radbooknum.Name = "radbooknum";
            this.radbooknum.Size = new System.Drawing.Size(47, 16);
            this.radbooknum.TabIndex = 0;
            this.radbooknum.TabStop = true;
            this.radbooknum.Text = "书号";
            this.radbooknum.UseVisualStyleBackColor = true;
            this.radbooknum.CheckedChanged += new System.EventHandler(this.radbooknum_CheckedChanged);
            // 
            // btnfetch
            // 
            this.btnfetch.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnfetch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnfetch.ForeColor = System.Drawing.Color.Black;
            this.btnfetch.Location = new System.Drawing.Point(91, 40);
            this.btnfetch.Name = "btnfetch";
            this.btnfetch.Size = new System.Drawing.Size(75, 38);
            this.btnfetch.TabIndex = 17;
            this.btnfetch.Text = "输入关键字按回车";
            this.btnfetch.UseVisualStyleBackColor = false;
            this.btnfetch.Click += new System.EventHandler(this.btnfetch_Click);
            // 
            // btnClose
            // 
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            this.btnClose.Location = new System.Drawing.Point(320, 91);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(65, 22);
            this.btnClose.TabIndex = 25;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRefersh
            // 
            this.btnRefersh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefersh.ForeColor = System.Drawing.Color.Black;
            this.btnRefersh.Location = new System.Drawing.Point(405, 58);
            this.btnRefersh.Name = "btnRefersh";
            this.btnRefersh.Size = new System.Drawing.Size(65, 22);
            this.btnRefersh.TabIndex = 24;
            this.btnRefersh.Text = "刷新";
            this.btnRefersh.UseVisualStyleBackColor = true;
            this.btnRefersh.Click += new System.EventHandler(this.btnRefersh_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancle.ForeColor = System.Drawing.Color.Black;
            this.btnCancle.Location = new System.Drawing.Point(320, 58);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(65, 22);
            this.btnCancle.TabIndex = 19;
            this.btnCancle.Text = "删除";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // btnsave
            // 
            this.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsave.ForeColor = System.Drawing.Color.Black;
            this.btnsave.Location = new System.Drawing.Point(405, 17);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(65, 22);
            this.btnsave.TabIndex = 18;
            this.btnsave.Text = "入库";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnadd
            // 
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnadd.ForeColor = System.Drawing.Color.Black;
            this.btnadd.Location = new System.Drawing.Point(320, 18);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(65, 22);
            this.btnadd.TabIndex = 16;
            this.btnadd.Text = "重置";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // dTPTime
            // 
            this.dTPTime.Location = new System.Drawing.Point(110, 179);
            this.dTPTime.Name = "dTPTime";
            this.dTPTime.Size = new System.Drawing.Size(188, 21);
            this.dTPTime.TabIndex = 15;
            this.dTPTime.CloseUp += new System.EventHandler(this.dTPTime_CloseUp);
            // 
            // txtInRecordPrice
            // 
            this.txtInRecordPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInRecordPrice.Location = new System.Drawing.Point(111, 133);
            this.txtInRecordPrice.Name = "txtInRecordPrice";
            this.txtInRecordPrice.Size = new System.Drawing.Size(187, 21);
            this.txtInRecordPrice.TabIndex = 14;
            this.toolTip1.SetToolTip(this.txtInRecordPrice, "请输入入库价");
            this.txtInRecordPrice.TextChanged += new System.EventHandler(this.txtInRecordPrice_TextChanged);
            // 
            // txtSalePrice
            // 
            this.txtSalePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSalePrice.Location = new System.Drawing.Point(111, 157);
            this.txtSalePrice.Name = "txtSalePrice";
            this.txtSalePrice.ReadOnly = true;
            this.txtSalePrice.Size = new System.Drawing.Size(187, 21);
            this.txtSalePrice.TabIndex = 13;
            this.toolTip1.SetToolTip(this.txtSalePrice, "请输入销售价");
            this.txtSalePrice.TextChanged += new System.EventHandler(this.txtSalePrice_TextChanged);
            // 
            // txtBookCount
            // 
            this.txtBookCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookCount.Location = new System.Drawing.Point(111, 110);
            this.txtBookCount.Name = "txtBookCount";
            this.txtBookCount.Size = new System.Drawing.Size(187, 21);
            this.txtBookCount.TabIndex = 12;
            this.toolTip1.SetToolTip(this.txtBookCount, "请输入正整型数字");
            this.txtBookCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBookCount_KeyPress);
            this.txtBookCount.TextChanged += new System.EventHandler(this.txtBookCount_TextChanged);
            // 
            // txtBookName
            // 
            this.txtBookName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookName.Location = new System.Drawing.Point(111, 88);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.ReadOnly = true;
            this.txtBookName.Size = new System.Drawing.Size(187, 21);
            this.txtBookName.TabIndex = 11;
            this.toolTip1.SetToolTip(this.txtBookName, "请输入图书名");
            // 
            // txtBookID
            // 
            this.txtBookID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookID.Location = new System.Drawing.Point(111, 65);
            this.txtBookID.Name = "txtBookID";
            this.txtBookID.Size = new System.Drawing.Size(187, 21);
            this.txtBookID.TabIndex = 10;
            this.toolTip1.SetToolTip(this.txtBookID, "请输入图书编号");
            this.txtBookID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBookID_KeyPress);
            this.txtBookID.TextChanged += new System.EventHandler(this.txtBookID_TextChanged_1);
            // 
            // txtzhanghao
            // 
            this.txtzhanghao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtzhanghao.Location = new System.Drawing.Point(111, 41);
            this.txtzhanghao.Name = "txtzhanghao";
            this.txtzhanghao.ReadOnly = true;
            this.txtzhanghao.Size = new System.Drawing.Size(187, 21);
            this.txtzhanghao.TabIndex = 9;
            // 
            // txtWaterID
            // 
            this.txtWaterID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWaterID.Location = new System.Drawing.Point(111, 18);
            this.txtWaterID.Name = "txtWaterID";
            this.txtWaterID.ReadOnly = true;
            this.txtWaterID.Size = new System.Drawing.Size(187, 21);
            this.txtWaterID.TabIndex = 8;
            this.toolTip1.SetToolTip(this.txtWaterID, "流水号");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(18, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "入库时间:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(18, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "销售价:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(18, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "入库价:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(18, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "数量:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(18, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "书名:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(18, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "书号:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(18, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "操作员账号:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(18, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "流水号(自动):";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // InRecord
            // 
            this.AcceptButton = this.btnfetch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 420);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgvInRecord);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(523, 447);
            this.MinimumSize = new System.Drawing.Size(523, 447);
            this.Name = "InRecord";
            this.Text = "图书入库";
            this.Load += new System.EventHandler(this.InRecord_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInRecord)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvInRecord;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInRecordPrice;
        private System.Windows.Forms.TextBox txtSalePrice;
        private System.Windows.Forms.TextBox txtBookCount;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.TextBox txtBookID;
        private System.Windows.Forms.TextBox txtzhanghao;
        private System.Windows.Forms.TextBox txtWaterID;
        private System.Windows.Forms.DateTimePicker dTPTime;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnfetch;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnRefersh;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radbookname;
        private System.Windows.Forms.RadioButton radbooknum;
        private System.Windows.Forms.TextBox textBox1;
    }
}