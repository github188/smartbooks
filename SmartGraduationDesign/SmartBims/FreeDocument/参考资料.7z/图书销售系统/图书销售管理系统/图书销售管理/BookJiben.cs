﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.图书销售管理
{
    public partial class BookJiben : Form
    {
        public BookJiben()
        {
            InitializeComponent();
        }

        private string Find()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string str = "select 书号 from bookrecord where 书号='" + txtBookID.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            string m = Convert.ToString(cmd.ExecuteScalar());
            con.Dispose();
            cmd.Dispose();
            con.Close();
            return m;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
           
            if (txtBookID.Text == "")
            {
                MessageBox.Show("书号不能为空", "提示");
                return;
            }
            if (txtBookName.Text == "")
            {
                MessageBox.Show("书名不能为空", "提示");
                return;
            }
            if (txtBookPrice.Text == "")
            {
                MessageBox.Show("单价不能为空", "提示");
                return;
            }
            if (txtchuban.Text == "")
            {
                MessageBox.Show("出版社不能为空", "提示");
                return;
            }
            if (txtEdit.Text == "")
            {
                MessageBox.Show("作者不能为空", "提示");
                return;
            }
            if (txtBookCount.Text == "")
            {
                MessageBox.Show("库存不能为空", "提示");
                return;
            }
            if (txtBookZheKou.Text == "")
            {
                MessageBox.Show("折扣不能为空", "提示");
                return;
            }
            if (Convert.ToSingle(txtBookZheKou.Text) < 0 || Convert.ToSingle(txtBookZheKou.Text) > 10)
            {
                MessageBox.Show("输入的折扣必须在0到10之间");
                txtBookZheKou.Text = "";
                txtBookZheKou.Focus();
                return;
            }

            else
            {
                if (Find() == "")
                {
                    string strSql = "insert into bookrecord values('" + txtBookID.Text + "','" + txtBookName.Text + "','" + txtchuban.Text + "','" + txtEdit.Text + "'," + txtBookPrice.Text + "," + txtBookCount.Text + ",'" + txtBookZheKou.Text + "')";
                    try
                    {
                        DB.ExecCommand(strSql);
                        MessageBox.Show("数据添加成功", "提示");
                        txtBookID.Text = "";
                        txtBookName.Text = "";
                        txtBookPrice.Text = "";
                        txtBookZheKou.Text = "";
                        txtchuban.Text = "";
                        txtEdit.Text = "";
                        txtBookCount.Text = "";
                    }
                    catch
                    {
                        //MessageBox.Show(ex.ToString());
                        MessageBox.Show("数据添加失败", "提示");
                        btnDelete.Enabled = btnSave.Enabled = false;
                    }
                    string strsql = "select*from bookrecord";
                    DB myDb = new DB();
                    DataSet ds = myDb.GetDataSet(strsql, "book");
                    dgvBookJiBen.DataSource = ds.Tables["book"];

                }
                else
                {
                    MessageBox.Show("该记录已经存在,不能添加重复记录", "图书入库");
                    btnDelete.Enabled = btnSave.Enabled = false;
                }
            }
          
        }



        private void txtBookCount_KeyPress(object sender, KeyPressEventArgs e)
        {
            InPutOnly.TextOnlyNum(sender, e);
        }



        private void btnFetch_Click(object sender, EventArgs e)
        {
            string strSql;
            if (radbookNum.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                strSql = "select*from bookrecord where 书号='" + txtguanjianzi.Text + "'";
                DB myDb = new DB();
                DataSet ds = myDb.GetDataSet(strSql, "book");
                dgvBookJiBen.DataSource = ds.Tables["book"];
            }
            if (radbookname.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                strSql = "select*from bookrecord where 书名 like '%" + txtguanjianzi.Text + "%'";
                DB myDb = new DB();
                DataSet ds = myDb.GetDataSet(strSql, "book");
                dgvBookJiBen.DataSource = ds.Tables["book"];
            }
            if (radchuban.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                strSql = "select*from bookrecord where 出版社 like'%" + txtguanjianzi.Text + "%'";
                DB myDb = new DB();
                DataSet ds = myDb.GetDataSet(strSql, "book");
                dgvBookJiBen.DataSource = ds.Tables["book"];
            }
            if (radEdit.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                strSql = "select*from bookrecord where 作者 like'%" + txtguanjianzi.Text + "%'";
                DB myDb = new DB();
                DataSet ds = myDb.GetDataSet(strSql, "book");
                dgvBookJiBen.DataSource = ds.Tables["book"];
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = DB.CreateConnection();
            SqlDataAdapter MyAdapter = new SqlDataAdapter("select*from bookrecord", con);
            //生成自动生成表单命令
            SqlCommandBuilder cb = new SqlCommandBuilder(MyAdapter);
            DataSet MyDataSet = new DataSet();
            //Fill方法
            MyAdapter.Fill(MyDataSet, "book");
            dgvBookJiBen.DataSource = MyDataSet.Tables["book"];
            string str = "";
            str = txtBookID.Text;
            //查找主键组合
            DataColumn[] keys = new DataColumn[1];
            keys[0] = MyDataSet.Tables["book"].Columns["书号"];
            MyDataSet.Tables["book"].PrimaryKey = keys;
            //定义主键组合
            object[] FindValues = new object[1];
            FindValues[0] = str;
            try
            {
                DataRow Row = MyDataSet.Tables["book"].Rows.Find(FindValues);
                if (Row != null)
                {
                    Row["书号"] = Convert.ToString(txtBookID.Text);
                    Row["书名"] = Convert.ToString(txtBookName.Text);
                    Row["出版社"] = Convert.ToString(txtchuban.Text);
                    Row["作者"] = Convert.ToString(txtEdit.Text);
                    Row["折扣"] = Convert.ToString(txtBookZheKou.Text);
                    MyAdapter.Update(MyDataSet, "book");
                    MessageBox.Show("数据修改成功");

                }
            }
            catch
            {
                MessageBox.Show("数据修改失败,请重新操作");
            }
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            string strsql = "select*from bookrecord";
            DB myDb = new DB();
            DataSet ds = myDb.GetDataSet(strsql, "book");
            dgvBookJiBen.DataSource = ds.Tables["book"];
            btnSave.Enabled = btnDelete.Enabled = false;
            txtBookID.Text = "";
            txtBookID.Focus();
            txtBookName.Text = "";
            txtBookPrice.Text = "";
            txtBookZheKou.Text = "";
            txtchuban.Text = "";
            txtEdit.Text = "";
            txtBookCount.Text = "";
        }

        private void dgvBookJiBen_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnSave.Enabled = true;
            btnDelete.Enabled = true;
            txtBookID.Text = Convert.ToString(dgvBookJiBen["书号", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtBookName.Text = Convert.ToString(dgvBookJiBen["书名", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtchuban.Text = Convert.ToString(dgvBookJiBen["出版社", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtEdit.Text = Convert.ToString(dgvBookJiBen["作者", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtBookPrice.Text = Convert.ToString(dgvBookJiBen["单价", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtBookCount.Text = Convert.ToString(dgvBookJiBen["库存量", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
            txtBookZheKou.Text = Convert.ToString(dgvBookJiBen["折扣", dgvBookJiBen.CurrentCell.RowIndex].Value).Trim();
        }

        private void btnchongzhi_Click(object sender, EventArgs e)
        {
            txtBookID.Focus();
            txtBookID.Text = "";
            txtBookName.Text = "";
            txtBookPrice.Text = "";
            txtBookZheKou.Text = "";
            txtchuban.Text = "";
            txtEdit.Text = "";
            txtBookCount.Text = "";
            btnSave.Enabled = btnDelete.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确实要删除该条数据吗?", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                SqlConnection con = DB.CreateConnection();
                SqlDataAdapter MyAdapter = new SqlDataAdapter("select*from bookrecord", con);
                //生成自动生成表单命令
                SqlCommandBuilder cb = new SqlCommandBuilder(MyAdapter);
                DataSet MyDataSet = new DataSet();
                //Fill方法
                MyAdapter.Fill(MyDataSet, "book");
                dgvBookJiBen.DataSource = MyDataSet.Tables["book"];
                string str = "";
                str = txtBookID.Text;
                //查找主键组合
                DataColumn[] keys = new DataColumn[1];
                keys[0] = MyDataSet.Tables["book"].Columns["书号"];
                MyDataSet.Tables["book"].PrimaryKey = keys;
                //定义主键组合
                object[] FindValues = new object[1];
                FindValues[0] = str;
                try
                {
                    DataRow Row = MyDataSet.Tables["book"].Rows.Find(FindValues);
                    if (Row != null)
                    {
                        Row.Delete();
                        MyAdapter.Update(MyDataSet, "book");
                        MessageBox.Show("数据删除成功");
                    }
                }
                catch
                {
                    MessageBox.Show("数据删除失败,请重新操作");
                }
                txtBookID.Text = "";
                txtBookName.Text = "";
                txtBookPrice.Text = "";
                txtBookZheKou.Text = "";
                txtchuban.Text = "";
                txtEdit.Text = "";
                txtBookCount.Text = "";
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BookJiben_Load(object sender, EventArgs e)
        {
            btnDelete.Enabled = btnSave.Enabled= false;
            btnFetch.Enabled = false;
            txtguanjianzi.Enabled = false;
            string strsql = "select*from bookrecord";
            DB myDb = new DB();
            DataSet ds = myDb.GetDataSet(strsql, "book");
            dgvBookJiBen.DataSource = ds.Tables["book"];
        }

        private void txtBookID_KeyPress(object sender, KeyPressEventArgs e)
        {
            InPutOnly.TextOnlyNum(sender, e);
        }

        private void radbookNum_CheckedChanged(object sender, EventArgs e)
        {
            if (radbookNum.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                btnFetch.Enabled = true;
                txtguanjianzi.Text = "";
                txtguanjianzi.Focus();
            }
        }

        private void radbookname_CheckedChanged(object sender, EventArgs e)
        {
            if (radbookname.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                btnFetch.Enabled = true;
                txtguanjianzi.Text = "";
                txtguanjianzi.Focus();
            }
        }

        private void radchuban_CheckedChanged(object sender, EventArgs e)
        {
            if (radchuban.Checked == true)
            {
                txtguanjianzi.Enabled = true;
                btnFetch.Enabled = true;
                txtguanjianzi.Text = "";
                txtguanjianzi.Focus();
            }
        }

        private void radEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (radEdit.Checked == true)
            {
                btnFetch.Enabled = true;
                txtguanjianzi.Enabled = true;
                txtguanjianzi.Text = "";
                txtguanjianzi.Focus();
            }
        }

        private void txtBookPrice_TextChanged(object sender, EventArgs e)
        {
            int len = txtBookPrice.Text.Length;
            if (len > 8)
            {
                MessageBox.Show("您输入的数字已经超出了合法界限,位数必须小于等于8");
                txtBookPrice.Text = "";
                txtBookPrice.Focus();
            }
            if (txtBookPrice.Text == "")
            {
                return;
            }
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtBookPrice.Text);
                }
                catch
                {
                    MessageBox.Show("价格输入必须为数字", "友情提示");
                    txtBookPrice.Text = "";
                }
            }
        }

        private void txtBookZheKou_TextChanged(object sender, EventArgs e)
        {
            if (txtBookZheKou.Text == "")
                return;
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtBookZheKou.Text);
                }
                catch
                {
                    MessageBox.Show("折扣输入必须为数字", "友情提示");
                    txtBookZheKou.Text = "";
                }
            }
        }

     

        private void txtBookID_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtBookID.Text.Length;
            if (len > 30)
            {
                MessageBox.Show("长度已经超出限定范围");
                txtBookID.Text = "";
                txtBookID.Focus();
            }
        }

        private void txtchuban_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtchuban.Text.Length;
            if (len > 100)
            {
                MessageBox.Show("长度已经超出限定范围");
                txtchuban.Text = "";
                txtchuban.Focus();
            }
        }

        private void txtBookName_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtBookName.Text.Length;
            if (len > 200)
            {
                MessageBox.Show("长度已经超出限定范围");
                txtBookName.Text = "";
                txtBookName.Focus();
            }
        }

        private void txtEdit_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtEdit.Text.Length;
            if (len > 30)
            {
                MessageBox.Show("长度已经超出限定范围");
                txtEdit.Text = "";
                txtEdit.Focus();
            }
        }

        private void txtBookCount_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtBookCount.Text.Length;
            if (len > 4)
            {
                MessageBox.Show("长度已经超出限定范围");
                txtBookCount.Text = "";
                txtBookCount.Focus();
            }
        }

        private void dgvBookJiBen_Scroll(object sender, ScrollEventArgs e)
        {
            dgvBookJiBen.HorizontalScrollingOffset.ToString();
        }
    }
}