﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;

namespace 图书销售管理系统.图书销售管理
{
    public partial class BookSaleDetil : Form
    {
        public BookSaleDetil()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SqlConnection con = DB.CreateConnection();
            string strSql = "select*from booksale";
            SqlDataAdapter MyAdapter = new SqlDataAdapter(strSql, con);
            DataSet3 ds = new DataSet3();
            MyAdapter.Fill(ds, "booksale");
            //CrystalReport31.Load(Application.StartupPath + "\\" + "CrystalReport3.rpt");
            CrystalReport31.SetDataSource(ds);
            crystalReportViewer1.ReportSource = CrystalReport31;
            
            con.Dispose();
        }
    }
}