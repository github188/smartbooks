﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.图书销售管理
{
    public partial class FrmPrice : Form
    {
        public FrmPrice()
        {
            InitializeComponent();
        }

        private string Fetch()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string str = "select 书号 from bookrecord where 书号='" + txtBooknum.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            string m = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
            cmd.Dispose();
            return m;
        }
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (Fetch() != "")
            {
                txtBookID.Text = txtBooknum.Text;
                SqlConnection con = DB.CreateConnection();
                con.Open();
                string strsql = "select 书名 from bookrecord where 书号='" + txtBooknum.Text + "'";
                string strsql1 = "select 折扣 from bookrecord where 书号='" + txtBooknum.Text + "'";
                SqlCommand cmd = new SqlCommand(strsql, con);
                SqlCommand cmd1 = new SqlCommand(strsql1, con);
                txtBookName.Text = cmd.ExecuteScalar().ToString();
                txtOldNumber.Text = cmd1.ExecuteScalar().ToString();
                con.Close();
                con.Dispose();
                cmd.Dispose();
                txtCaoZuo.Text = "修改";
                txtID.Text = "";
                txtNewNumber.Text = "";
                dateTimePicker1.Text = DateTime.Now.ToLongDateString();
            }
            else
                MessageBox.Show("书库中没有该书");
            btnSave.Enabled = true;
            btnCancle.Enabled = false;
        }

        private void FrmPrice_Load_1(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            btnCancle.Enabled = false;
            string strsql = "select*from mantainrecord";
            DB mydb = new DB();
            DataSet ds = mydb.GetDataSet(strsql, "book");
            dgvFrmPrice.DataSource = ds.Tables["book"];
            show ss = new show();
            txtCaozuoyuan.Text = ss.caozuotest;
            
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确实要删除该条记录吗?", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                string str = "delete mantainrecord where 流水号=" + txtID.Text + "";
                try
                {
                    DB.ExecCommand(str);
                    MessageBox.Show("数据删除成功!", "提示");
                }
                catch
                {
                    MessageBox.Show("数据删除失败!", "提示");
                }
            }
            string strsql = "select*from mantainrecord";
            DB mydb = new DB();
            DataSet ds = mydb.GetDataSet(strsql, "book");
            dgvFrmPrice.DataSource = ds.Tables["book"];
        }

        private void btnqingKong_Click(object sender, EventArgs e)
        {

            txtCaoZuo.Text = "";
            txtID.Text = "";
            txtNewNumber.Text = "";

            dateTimePicker1.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCaoZuo.Text == "")
            {
                MessageBox.Show("操作不能为空", "友情提示");
                txtCaoZuo.Focus();
                return;
            }
            if (txtNewNumber.Text == "")
            {
                MessageBox.Show("操作后的数据不能为空", "友情提示");
                txtNewNumber.Focus();
                return;
            }
            if ((Convert.ToSingle(txtNewNumber.Text) >= 0) && (Convert.ToSingle(txtNewNumber.Text) <= 10))
            {
                string strsql = "insert into mantainrecord values('" + Convert.ToDateTime(dateTimePicker1.Text).ToShortDateString() + "','" + txtBookID.Text + "','" + txtCaozuoyuan.Text + "','" + txtCaoZuo.Text + "'," + txtOldNumber.Text + "," + txtNewNumber.Text + ")";
                string strSql = "update bookrecord set 折扣=" + txtNewNumber.Text + " where 书号='" + txtBookID.Text + "'";
                try
                {
                    DB.ExecCommand(strsql);
                    DB.ExecCommand(strSql);
                    MessageBox.Show("保存数据成功", "提示");
                    txtNewNumber.Text = "";
                    txtOldNumber.Text = "";
                    txtCaoZuo.Text = "";
                    txtBookName.Text = "";
                    txtBooknum.Text = "";
                    txtBookID.Text = "";
                    btnSave.Enabled = false;
                    txtBooknum.Focus();
                }
                catch
                {
                    MessageBox.Show("保存数据失败", "提示");
                }
                string strsql1 = "select*from mantainrecord";
                DB mydb = new DB();
                DataSet ds = mydb.GetDataSet(strsql1, "book");
                dgvFrmPrice.DataSource = ds.Tables["book"];
            }
            else
            {
                MessageBox.Show("折扣必须在0到10之间", "提示");
                txtNewNumber.Text = "";
                txtNewNumber.Focus();
            }
            
        }

        private void txtCaoZuo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBooknum_KeyPress(object sender, KeyPressEventArgs e)
        {
            InPutOnly.TextOnlyNum(sender, e);
        }

      

        private void txtNewNumber_TextChanged(object sender, EventArgs e)
        {
            if (txtNewNumber.Text == "")
                return;
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtNewNumber.Text);
                }
                catch
                {
                    MessageBox.Show("新数据必须为数字,才能进行输入", "提示");
                    txtNewNumber.Text = "";
                }
            }
        }

        private void dgvFrmPrice_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            btnCancle.Enabled = true;
            txtID.Text = Convert.ToString(dgvFrmPrice["流水号", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            txtNewNumber.Text = Convert.ToString(dgvFrmPrice["新数据", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            txtOldNumber.Text = Convert.ToString(dgvFrmPrice["旧数据", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            txtBookID.Text = Convert.ToString(dgvFrmPrice["书号", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            txtCaoZuo.Text = Convert.ToString(dgvFrmPrice["操作", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            //txtCaozuoyuan.Text = Convert.ToString(dgvFrmPrice["操作员账号", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
            dateTimePicker1.Text = Convert.ToString(dgvFrmPrice["操作日期", dgvFrmPrice.CurrentCell.RowIndex].Value).Trim();
        }

       

        private void dateTimePicker1_CloseUp(object sender, EventArgs e)
        {
            string s = DateTime.Now.ToShortDateString();
            if (Convert.ToDateTime(s) < Convert.ToDateTime(dateTimePicker1.Text))
            {
                MessageBox.Show("选择时间已经超出现在当前时间,请重新进行选择", "友情提示");

                dateTimePicker1.Text = DateTime.Now.ToLongDateString();
                return;

            }
        }



        
    }
}