﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.图书销售管理
{
    public partial class SaleDatia : Form
    {
        public SaleDatia()
        {
            InitializeComponent();
        }

       

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SqlConnection con = DB.CreateConnection();
            string str = "select*from SalesDetail";
            SqlDataAdapter sda = new SqlDataAdapter(str, con);
            DataSet2 ds = new DataSet2();
            sda.Fill(ds, "salesDetail");
            //CrystalReport21.Load(Application.StartupPath + "\\" + "CrystalReport2.rpt");
            CrystalReport21.SetDataSource(ds);
            crystalReportViewer1.ReportSource = CrystalReport21;
            con.Dispose();
        }
    }
}