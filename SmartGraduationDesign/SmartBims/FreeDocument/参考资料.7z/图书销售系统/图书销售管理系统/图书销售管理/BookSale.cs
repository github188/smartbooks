﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.图书销售管理
{
    public partial class BookSale : Form
    {
        public BookSale()
        {
            InitializeComponent();
        }

        show ss = new show();
        int m;
        private string Find()
        {
            string strsql = "";
            SqlConnection con = DB.CreateConnection();
            con.Open();
            if (radbookID.Checked == true)
            {
                strsql = "select 书号 from bookrecord where 书号='" + txtBookID.Text + "'";
            }
            if (radbookname.Checked == true)
            {
                strsql = "select 书号 from bookrecord where 书名='" + txtBookID.Text + "'";
            }
            SqlCommand cmd = new SqlCommand(strsql, con);
            string m = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
            cmd.Dispose();
            return m;
        }
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (Find() != "")
            {
                txtbookNO.Text = txtBookID.Text;
                SqlConnection con = DB.CreateConnection();
                con.Open();
                if (radbookID.Checked == true)
                {
                    string Strsql = "select 书名 from bookrecord where 书号='" + txtBookID.Text + "'";
                    SqlCommand cmd = new SqlCommand(Strsql, con);
                    txtBookName.Text = cmd.ExecuteScalar().ToString();
                    string strsql = "select 单价 from bookrecord where 书号='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strsql, con);
                    txtBookPrice.Text = cmd.ExecuteScalar().ToString();
                    string strSql = "select 折扣 from bookrecord where 书号='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strSql, con);
                    txtBookZheKou.Text = cmd.ExecuteScalar().ToString();
                    string strSql1 = "select 库存量 from bookrecord where 书号='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strSql1, con);
                    m = Convert.ToInt32(cmd.ExecuteScalar());
                    label10.Text = "当前库存量: " + m.ToString() + "  本";
                    cmd.Dispose();
                }
                if (radbookname.Checked == true)
                {
                    txtBookName.Text = txtBookID.Text;
                    string Strsql = "select 书号 from bookrecord where 书名='" + txtBookID.Text + "'";
                    SqlCommand cmd = new SqlCommand(Strsql, con);
                    txtbookNO.Text = cmd.ExecuteScalar().ToString();
                    string strsql = "select 单价 from bookrecord where 书名='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strsql, con);
                    txtBookPrice.Text = cmd.ExecuteScalar().ToString();
                    string strSql = "select 折扣 from bookrecord where 书名='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strSql, con);
                    txtBookZheKou.Text = cmd.ExecuteScalar().ToString();
                    string strSql1 = "select 库存量 from bookrecord where 书名='" + txtBookID.Text + "'";
                    cmd = new SqlCommand(strSql1, con);
                    m = Convert.ToInt32(cmd.ExecuteScalar());
                    label10.Text = "当前库存量: " +m.ToString() + "  本";
                    cmd.Dispose();
                }
                con.Close();
                con.Dispose();

            }
            else
            {
                MessageBox.Show("图书库存中不存在该书,请重新输入", "提示");
                txtBookID.Text = "";
            }
            txtNumber.Text = "";
            txtyingfu.Text = "";
            txtReturn.Text = "";
            txtfukuan.Text = "";
        }

        private void btnJiSuan_Click(object sender, EventArgs e)
        {
            if (Convert.ToSingle(txtyingfu.Text) <= Convert.ToSingle(txtfukuan.Text))
                txtReturn.Text = (Convert.ToDouble(txtfukuan.Text) - Convert.ToDouble(txtyingfu.Text)).ToString();
            else
                MessageBox.Show("客户所付的金额不够!请提醒对方补钱", "提示");
        }
        private int count()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string strSql = "select 库存量 from bookrecord where 书号='" + txtbookNO.Text + "'";
            SqlCommand cmd = new SqlCommand(strSql, con);
            int m = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
            cmd.Dispose();
            return m;
        }


        private void txtNumber_KeyPress(object sender, KeyPressEventArgs e)
        {

            InPutOnly.TextOnlyNum(sender, e);
        }



        private void BookSale_Load(object sender, EventArgs e)
        {
            btnJieZhang.Enabled = false;
            btnJiSuan.Enabled = false;
            txtBookID.Enabled = false;
        }

        private void txtfukuan_KeyPress(object sender, KeyPressEventArgs e)
        {
            btnJiSuan.Enabled = true;
        }
        private void txtReturn_TextChanged(object sender, EventArgs e)
        {
            if (txtReturn.Text == "")
            {
                btnJieZhang.Enabled = false;

                return;
            }
            else
            {
                btnJieZhang.Enabled = true;
                btnJiSuan.Enabled = false;
            }
        }

        private void btnJieZhang_Click(object sender, EventArgs e)
        {
            string strsql1 = "";
            if (count() >= Convert.ToInt32(txtNumber.Text))
            {
                int s = 0;
                if (txtNumber.Text == Convert.ToString(s) || txtNumber.Text == "")
                    MessageBox.Show("您还没有购买图书,不能进行结账", "提示");
                else
                {
                    show ss = new show();
                    //string strsql="update bookrecord set 库存量=库存量-"+txtNumber.Text+" where 书号='"+txtBookID.Text+"'";
                    //string strSql = "insert into booksale(操作员账号,总金额) values('" + ss.caozuotest + "'," + txtfukuan.Text + ")";
                    if (radbookID.Checked == true)
                    {
                        strsql1 = "begin tran update bookrecord set 库存量=库存量-" + txtNumber.Text + " where 书号='" + txtBookID.Text + "' insert into booksale(操作员账号,总金额) values('" + ss.caozuotest + "'," + txtfukuan.Text + ") insert into SalesDetail values('" + ss.caozuotest + "','" + txtbookNO.Text + "','" + txtBookName.Text + "'," + txtBookPrice.Text + "," + txtNumber.Text + "," + txtBookZheKou.Text + ") if(@@RowCount=0) rollback tran else commit tran";
                    }
                    if (radbookname.Checked == true)
                    {
                        strsql1 = "begin tran update bookrecord set 库存量=库存量-" + txtNumber.Text + " where 书名='" + txtBookID.Text + "' insert into booksale(操作员账号,总金额) values('" + ss.caozuotest + "'," + txtfukuan.Text + ") insert into SalesDetail values('" + ss.caozuotest + "','" + txtbookNO.Text + "','" + txtBookName.Text + "'," + txtBookPrice.Text + "," + txtNumber.Text + "," + txtBookZheKou.Text + ") if(@@RowCount=0) rollback tran else commit tran";
                    }
                    try
                    {
                        DB.ExecCommand(strsql1);
                        //DB.ExecCommand(strSql);
                        MessageBox.Show("结账成功", "提示");
                        label10.Text = "当前库存量: " + (m - Convert.ToInt32(txtNumber.Text)).ToString() + "  本";
                    }
                    catch
                    {
                        //MessageBox.Show(ex.ToString());
                        MessageBox.Show("结账失败,请重新操作", "提示");
                    }
                }
            }
            else
            {
                MessageBox.Show("库存不足,不能进行正常操作", "友情提示");
            }
            txtfukuan.Text = "";
            txtNumber.Text = "";
            txtReturn.Text = "";
            txtyingfu.Text = "";
            txtNumber.Focus();
        }





        private void txtNumber_TextChanged(object sender, EventArgs e)
        {

            if (txtNumber.Text != "")
            {

                if (count() >= Convert.ToInt32(txtNumber.Text))
                {
                    txtyingfu.Text = (Convert.ToDouble(txtNumber.Text) * Convert.ToDouble(txtBookSale.Text)).ToString();
                }
                else
                {
                    MessageBox.Show("库存不足", "提示");
                    //int s = 0;
                    //txtNumber.Text = Convert.ToString(s);
                    txtNumber.Text = "";
                    txtyingfu.Text = "";
                    txtfukuan.Text = "";
                }
            }


        }

        private void txtBookZheKou_TextChanged(object sender, EventArgs e)
        {
            if (txtBookZheKou.Text != "" && txtBookPrice.Text != "")
            {
                txtBookSale.Text = ((Convert.ToSingle(txtBookPrice.Text)) * ((Convert.ToSingle(txtBookZheKou.Text)) / 10)).ToString();
            }
        }

        private void txtfukuan_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtfukuan.Text.Length;
            if (len > 8)
            {
                MessageBox.Show("已经超出价格的限定范围");
                return;
            }
            if (txtfukuan.Text == "")
            {
                btnJiSuan.Enabled = false;
                txtReturn.Text = "";
                return;
            }
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtfukuan.Text);
                }
                catch
                {
                    MessageBox.Show("您必须输入数字", "友情提示");
                    txtfukuan.Text = "";
                    return;
                }
            }
        }

       

        private void radbookID_CheckedChanged_1(object sender, EventArgs e)
        {
            if (radbookID.Checked == true)
            {
                txtBookID.Enabled = true;
                txtBookID.Text = "";
                txtBookName.Text = "";
                txtbookNO.Text = "";
                txtBookPrice.Text = "";
                txtBookSale.Text = "";
                txtBookZheKou.Text = "";
                label10.Text = "当前库存量: ";
                txtBookID.Focus();
            }
        }

        private void radbookname_CheckedChanged_1(object sender, EventArgs e)
        {
            if (radbookname.Checked == true)
            {
                txtBookID.Enabled = true;
                txtBookID.Text = "";
                txtBookName.Text = "";
                txtbookNO.Text = "";
                txtBookPrice.Text = "";
                txtBookSale.Text = "";
                txtBookZheKou.Text = "";
                label10.Text = "当前库存量: ";
                txtBookID.Focus();
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}