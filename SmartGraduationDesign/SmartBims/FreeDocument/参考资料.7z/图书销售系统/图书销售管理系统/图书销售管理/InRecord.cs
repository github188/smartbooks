﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using  System.Data.SqlClient ;

namespace 图书销售管理系统.图书销售管理
{
    public partial class InRecord : Form
    {
        public InRecord()
        {
            InitializeComponent();
        }

        private string Find()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string strSql = "select 书号 from bookrecord where 书号='" + txtBookID.Text + "'";
            SqlCommand cmd = new SqlCommand(strSql, con);
            string m = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
            cmd.Dispose();
            return m;
        }
        private int OnlyName()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string strSql = "select 流水号 from inrecord where 书号='" + txtBookID.Text + "'";
            SqlCommand cmd = new SqlCommand(strSql, con);
            int n = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            con.Dispose();
            cmd.Dispose();
            return n;
        }
        private void InRecord_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = btnfetch.Enabled = false;
            show ss = new show();
            txtzhanghao.Text = ss.caozuotest;
            string strsql = "select*from inrecord";
            DB mydb = new DB();
            DataSet ds = mydb.GetDataSet(strsql, "book");
            dgvInRecord.DataSource = ds.Tables["book"];
            btnCancle.Enabled = false;
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            txtWaterID.Text = "";
            txtSalePrice.Text = "";
            txtInRecordPrice.Text = "";
            txtBookName.Text = "";
            txtBookID.Text = "";
            txtBookID.Focus();
            btnCancle.Enabled = false;
            txtBookCount.Text = "";
            dTPTime.Text = DateTime.Now.ToLongDateString();
        }

        private void btnfetch_Click(object sender, EventArgs e)
        {
            string strSql;
            if (radbooknum.Checked == true)
            {
              
                strSql = "select*from inrecord where 书号 like'%" + textBox1.Text + "%'";
                DB db = new DB();
                DataSet ds = db.GetDataSet(strSql, "book");
                dgvInRecord.DataSource = ds.Tables["book"];
            }
            if (radbookname.Checked == true)
            {
                
                
                strSql = "select*from inrecord where 书名 like'%" + textBox1.Text + "%'";
                DB db = new DB();
                DataSet ds = db.GetDataSet(strSql, "book");
                dgvInRecord.DataSource = ds.Tables["book"];
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtBookID.Text == "")
            {
                MessageBox.Show("书号不允许为空", "图书入库");
                return;
            }
            if (txtBookName.Text == "")
            {
                MessageBox.Show("书名不允许为空", "图书入库");
                return;
            }
            if (txtInRecordPrice.Text == "")
            {
                MessageBox.Show("入库价不能为空", "图书入库");
                return;
            }
            if (txtSalePrice.Text == "")
            {
                MessageBox.Show("销售价不能为空", "图书入库");
                return;
            }
            if (txtBookCount.Text == "")
            {
                MessageBox.Show("库存量不能为空", "图书入库");
                return;
            }
            if (txtInRecordPrice.Text != "")
            {
                if (Convert.ToSingle(txtInRecordPrice.Text) >= Convert.ToSingle(txtSalePrice.Text))
                {
                    MessageBox.Show("入库价必须小于销售价,才能进行图书入库", "提示");
                    txtSalePrice.Text = "";
                    txtSalePrice.Focus();
                }

            }


            if (Find() == "")
            {
                MessageBox.Show("该书为新书,请在图书基本资料里添加该书后再进行入库操作", "提示");
                图书销售管理.BookJiben frm = new BookJiben();
                frm.ShowDialog();
            }
            else
            {

                //if (OnlyName() == 0)
                //{
                string strSql = "insert into inrecord values('" + txtzhanghao.Text + "','" + txtBookID.Text + "','" + txtBookName.Text + "','" + Convert.ToDateTime(dTPTime.Text).ToShortDateString() + "'," + txtInRecordPrice.Text + "," + txtBookCount.Text + "," + txtSalePrice.Text + ")";
                string strSql1 = "update  bookrecord set 库存量=" + txtBookCount.Text + "+库存量 where 书号='" + txtBookID.Text + "'";
                try
                {
                    DB.ExecCommand(strSql);
                    DB.ExecCommand(strSql1);
                    MessageBox.Show("图书入库成功", "提示");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    MessageBox.Show("图书入库失败", "提示");
                }
                string strsql = "select*from inrecord";
                DB mydb = new DB();
                DataSet ds = mydb.GetDataSet(strsql, "book");
                dgvInRecord.DataSource = ds.Tables["book"];
                btnCancle.Enabled = false;
                //}
                //else
                //    MessageBox.Show("已经有图书号为" + txtBookID.Text + "的记录,不能添加重复记录!", "提示");
            }

        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确实要删除该条数据吗?", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                SqlConnection con = DB.CreateConnection();
                SqlDataAdapter MyAdapter = new SqlDataAdapter("select*from inrecord", con);
                //生成自动生成表单命令
                SqlCommandBuilder cb = new SqlCommandBuilder(MyAdapter);
                DataSet MyDataSet = new DataSet();
                //Fill方法
                MyAdapter.Fill(MyDataSet, "book");
                dgvInRecord.DataSource = MyDataSet.Tables["book"];
                string str = "";
                str = txtWaterID.Text;
                //查找主键组合
                DataColumn[] keys = new DataColumn[1];
                keys[0] = MyDataSet.Tables["book"].Columns["流水号"];
                MyDataSet.Tables["book"].PrimaryKey = keys;
                //定义主键组合
                object[] FindValues = new object[1];
                FindValues[0] = str;
                try
                {
                    DataRow Row = MyDataSet.Tables["book"].Rows.Find(FindValues);
                    if (Row != null)
                    {
                        Row.Delete();
                        MyAdapter.Update(MyDataSet, "book");
                        MessageBox.Show("删除成功");
                    }
                }
                catch
                {
                    MessageBox.Show("删除失败,请重新操作");
                }
            }
        }

        private void dgvInRecord_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnCancle.Enabled = true;
            txtWaterID.Text = Convert.ToString(dgvInRecord["流水号", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            //txtzhanghao.Text = Convert.ToString(dgvInRecord["操作员账号", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            txtBookID.Text = Convert.ToString(dgvInRecord["书号", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            txtBookName.Text = Convert.ToString(dgvInRecord["书名", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            txtInRecordPrice.Text = Convert.ToString(dgvInRecord["入库价", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            txtSalePrice.Text = Convert.ToString(dgvInRecord["出售价", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            dTPTime.Text = Convert.ToString(dgvInRecord["入库日期", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
            txtBookCount.Text = Convert.ToString(dgvInRecord["数量", dgvInRecord.CurrentCell.RowIndex].Value).Trim();
        }

        private void btnRefersh_Click(object sender, EventArgs e)
        {
            string strsql = "select*from inrecord";
            DB mydb = new DB();
            DataSet ds = mydb.GetDataSet(strsql, "book");
            dgvInRecord.DataSource = ds.Tables["book"];
            txtWaterID.Text = "";
            txtSalePrice.Text = "";
            txtInRecordPrice.Text = "";
            txtBookName.Text = "";
            txtBookID.Text = "";
            txtBookCount.Text = "";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBookID_KeyPress(object sender, KeyPressEventArgs e)
        {
            InPutOnly.TextOnlyNum(sender, e);
        }

        private void txtBookCount_KeyPress(object sender, KeyPressEventArgs e)
        {
            InPutOnly.TextOnlyNum(sender, e);
        }


        private void radbooknum_CheckedChanged(object sender, EventArgs e)
        {
            if (radbooknum.Checked == true)
            {
                textBox1.Text = "";
                
                textBox1.Enabled = true;
                btnfetch.Enabled = true;
                textBox1.Focus();
            }
        }

        private void radbookname_CheckedChanged(object sender, EventArgs e)
        {
            if (radbookname.Enabled == true)
            {
                textBox1.Text = "";
               
                textBox1.Enabled = true;
                btnfetch.Enabled = true;
                textBox1.Focus();
            }
        }

        private void txtInRecordPrice_TextChanged(object sender, EventArgs e)
        {
            int len;
            len = txtInRecordPrice.Text.Length;
            if (len > 8)
            {
                MessageBox.Show("输入长度已经超出限定范围");
                txtInRecordPrice.Text = "";
                txtInRecordPrice.Focus();
            }
            if (txtInRecordPrice.Text == "")
                return;
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtInRecordPrice.Text);
                }
                catch
                {
                    MessageBox.Show("入库价必须为数字,才能进行输入", "提示");
                    txtInRecordPrice.Text = "";
                }
            }
        }

        private void txtSalePrice_TextChanged(object sender, EventArgs e)
        {
            if (txtSalePrice.Text == "")
                return;
            else
            {
                try
                {
                    decimal s = Convert.ToDecimal(txtSalePrice.Text);
                }
                catch
                {
                    MessageBox.Show("入库价必须为数字,才能进行输入", "提示");
                    txtSalePrice.Text = "";
                }
            }
        }
        private void txtBookID_TextChanged_1(object sender, EventArgs e)
        {
            string str = "";
            SqlConnection con = DB.CreateConnection();
            con.Open();
            str = "select 书名 from bookrecord where 书号='" + txtBookID.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            txtBookName.Text = Convert.ToString(cmd.ExecuteScalar());
            string str1 = "select 单价 from bookrecord where 书号='" + txtBookID.Text + "'";
            cmd = new SqlCommand(str1, con);
            txtSalePrice.Text = Convert.ToString(cmd.ExecuteScalar());
            con.Dispose();
            con.Close();
            cmd.Dispose();
        }

        private void txtBookCount_TextChanged(object sender, EventArgs e)
        {
          
            int len;
            len = txtBookCount.Text.Length;
            if (len > 4)
            {
                MessageBox.Show("输入长度已经超出限定范围");
                txtBookCount.Text = "";
                txtBookCount.Focus();
            }
        }

        private void dTPTime_CloseUp(object sender, EventArgs e)
        {
            string s = DateTime.Now.ToShortDateString();
            if (Convert.ToDateTime(s) < Convert.ToDateTime(dTPTime.Text))
            {
                MessageBox.Show("选择时间已经超出现在当前时间,请重新进行选择", "友情提示");
                dTPTime.Text = DateTime.Now.ToLongDateString();
                return;
            }
        }

     
    }
}