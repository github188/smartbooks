﻿namespace 图书销售管理系统.图书销售管理
{
    partial class BookSale
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookSale));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radbookname = new System.Windows.Forms.RadioButton();
            this.radbookID = new System.Windows.Forms.RadioButton();
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtBookID = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtbookNO = new System.Windows.Forms.TextBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.txtBookPrice = new System.Windows.Forms.TextBox();
            this.txtBookZheKou = new System.Windows.Forms.TextBox();
            this.txtBookSale = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnJieZhang = new System.Windows.Forms.Button();
            this.btnJiSuan = new System.Windows.Forms.Button();
            this.txtReturn = new System.Windows.Forms.TextBox();
            this.txtfukuan = new System.Windows.Forms.TextBox();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtyingfu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radbookname);
            this.groupBox1.Controls.Add(this.radbookID);
            this.groupBox1.Controls.Add(this.btnEnter);
            this.groupBox1.Controls.Add(this.txtBookID);
            this.groupBox1.ForeColor = System.Drawing.Color.Teal;
            this.groupBox1.Location = new System.Drawing.Point(13, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(362, 67);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请输入书号";
            // 
            // radbookname
            // 
            this.radbookname.AutoSize = true;
            this.radbookname.ForeColor = System.Drawing.Color.Black;
            this.radbookname.Location = new System.Drawing.Point(101, 15);
            this.radbookname.Name = "radbookname";
            this.radbookname.Size = new System.Drawing.Size(47, 16);
            this.radbookname.TabIndex = 3;
            this.radbookname.TabStop = true;
            this.radbookname.Text = "书名";
            this.radbookname.UseVisualStyleBackColor = true;
            this.radbookname.CheckedChanged += new System.EventHandler(this.radbookname_CheckedChanged_1);
            // 
            // radbookID
            // 
            this.radbookID.AutoSize = true;
            this.radbookID.ForeColor = System.Drawing.Color.Black;
            this.radbookID.Location = new System.Drawing.Point(22, 16);
            this.radbookID.Name = "radbookID";
            this.radbookID.Size = new System.Drawing.Size(47, 16);
            this.radbookID.TabIndex = 2;
            this.radbookID.TabStop = true;
            this.radbookID.Text = "书号";
            this.radbookID.UseVisualStyleBackColor = true;
            this.radbookID.CheckedChanged += new System.EventHandler(this.radbookID_CheckedChanged_1);
            // 
            // btnEnter
            // 
            this.btnEnter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEnter.ForeColor = System.Drawing.Color.Black;
            this.btnEnter.Location = new System.Drawing.Point(277, 37);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(63, 21);
            this.btnEnter.TabIndex = 1;
            this.btnEnter.Text = "按回车";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // txtBookID
            // 
            this.txtBookID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookID.Location = new System.Drawing.Point(22, 38);
            this.txtBookID.Multiline = true;
            this.txtBookID.Name = "txtBookID";
            this.txtBookID.Size = new System.Drawing.Size(250, 21);
            this.txtBookID.TabIndex = 0;
            this.toolTip1.SetToolTip(this.txtBookID, "请输入图书编号");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtbookNO);
            this.groupBox2.Controls.Add(this.txtBookName);
            this.groupBox2.Controls.Add(this.txtBookPrice);
            this.groupBox2.Controls.Add(this.txtBookZheKou);
            this.groupBox2.Controls.Add(this.txtBookSale);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.ForeColor = System.Drawing.Color.Teal;
            this.groupBox2.Location = new System.Drawing.Point(13, 82);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 196);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "书籍信息";
            // 
            // txtbookNO
            // 
            this.txtbookNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbookNO.Location = new System.Drawing.Point(59, 24);
            this.txtbookNO.Name = "txtbookNO";
            this.txtbookNO.ReadOnly = true;
            this.txtbookNO.Size = new System.Drawing.Size(123, 21);
            this.txtbookNO.TabIndex = 9;
            // 
            // txtBookName
            // 
            this.txtBookName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookName.Location = new System.Drawing.Point(59, 58);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.ReadOnly = true;
            this.txtBookName.Size = new System.Drawing.Size(123, 21);
            this.txtBookName.TabIndex = 8;
            // 
            // txtBookPrice
            // 
            this.txtBookPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookPrice.Location = new System.Drawing.Point(59, 93);
            this.txtBookPrice.Name = "txtBookPrice";
            this.txtBookPrice.ReadOnly = true;
            this.txtBookPrice.Size = new System.Drawing.Size(123, 21);
            this.txtBookPrice.TabIndex = 7;
            // 
            // txtBookZheKou
            // 
            this.txtBookZheKou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookZheKou.Location = new System.Drawing.Point(59, 127);
            this.txtBookZheKou.Name = "txtBookZheKou";
            this.txtBookZheKou.ReadOnly = true;
            this.txtBookZheKou.Size = new System.Drawing.Size(123, 21);
            this.txtBookZheKou.TabIndex = 6;
            this.txtBookZheKou.TextChanged += new System.EventHandler(this.txtBookZheKou_TextChanged);
            // 
            // txtBookSale
            // 
            this.txtBookSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookSale.Location = new System.Drawing.Point(59, 161);
            this.txtBookSale.Name = "txtBookSale";
            this.txtBookSale.ReadOnly = true;
            this.txtBookSale.Size = new System.Drawing.Size(123, 21);
            this.txtBookSale.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(11, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "出售价:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(11, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "折扣:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(11, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "单价:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(11, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "书名:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(11, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "书号:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnJieZhang);
            this.groupBox3.Controls.Add(this.btnJiSuan);
            this.groupBox3.Controls.Add(this.txtReturn);
            this.groupBox3.Controls.Add(this.txtfukuan);
            this.groupBox3.Controls.Add(this.txtNumber);
            this.groupBox3.Controls.Add(this.txtyingfu);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.ForeColor = System.Drawing.Color.Teal;
            this.groupBox3.Location = new System.Drawing.Point(221, 82);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(154, 196);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "付款信息";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btnJieZhang
            // 
            this.btnJieZhang.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJieZhang.ForeColor = System.Drawing.Color.Black;
            this.btnJieZhang.Location = new System.Drawing.Point(86, 161);
            this.btnJieZhang.Name = "btnJieZhang";
            this.btnJieZhang.Size = new System.Drawing.Size(51, 23);
            this.btnJieZhang.TabIndex = 9;
            this.btnJieZhang.Text = "结账";
            this.btnJieZhang.UseVisualStyleBackColor = true;
            this.btnJieZhang.Click += new System.EventHandler(this.btnJieZhang_Click);
            // 
            // btnJiSuan
            // 
            this.btnJiSuan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnJiSuan.ForeColor = System.Drawing.Color.Black;
            this.btnJiSuan.Location = new System.Drawing.Point(19, 161);
            this.btnJiSuan.Name = "btnJiSuan";
            this.btnJiSuan.Size = new System.Drawing.Size(51, 23);
            this.btnJiSuan.TabIndex = 8;
            this.btnJiSuan.Text = "计算";
            this.btnJiSuan.UseVisualStyleBackColor = true;
            this.btnJiSuan.Click += new System.EventHandler(this.btnJiSuan_Click);
            // 
            // txtReturn
            // 
            this.txtReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReturn.Location = new System.Drawing.Point(69, 123);
            this.txtReturn.Name = "txtReturn";
            this.txtReturn.ReadOnly = true;
            this.txtReturn.Size = new System.Drawing.Size(79, 21);
            this.txtReturn.TabIndex = 7;
            this.txtReturn.TextChanged += new System.EventHandler(this.txtReturn_TextChanged);
            // 
            // txtfukuan
            // 
            this.txtfukuan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtfukuan.Location = new System.Drawing.Point(69, 89);
            this.txtfukuan.Name = "txtfukuan";
            this.txtfukuan.Size = new System.Drawing.Size(79, 21);
            this.txtfukuan.TabIndex = 6;
            this.toolTip1.SetToolTip(this.txtfukuan, "请输入客户所交现金");
            this.txtfukuan.TextChanged += new System.EventHandler(this.txtfukuan_TextChanged);
            this.txtfukuan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfukuan_KeyPress);
            // 
            // txtNumber
            // 
            this.txtNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumber.Location = new System.Drawing.Point(69, 20);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(79, 21);
            this.txtNumber.TabIndex = 4;
            this.toolTip1.SetToolTip(this.txtNumber, "请输入所购书的数量");
            this.txtNumber.TextChanged += new System.EventHandler(this.txtNumber_TextChanged);
            this.txtNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumber_KeyPress);
            // 
            // txtyingfu
            // 
            this.txtyingfu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtyingfu.Location = new System.Drawing.Point(69, 56);
            this.txtyingfu.Name = "txtyingfu";
            this.txtyingfu.ReadOnly = true;
            this.txtyingfu.Size = new System.Drawing.Size(79, 21);
            this.txtyingfu.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(11, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "应还:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(11, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "客户付款:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(11, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "应付:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(11, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "书数量:";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 285);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 12);
            this.label10.TabIndex = 3;
            this.label10.Text = "当前库存量为:";
            // 
            // BookSale
            // 
            this.AcceptButton = this.btnEnter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 295);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(400, 329);
            this.MinimumSize = new System.Drawing.Size(400, 329);
            this.Name = "BookSale";
            this.Text = "图书销售";
            this.Load += new System.EventHandler(this.BookSale_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox txtBookID;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbookNO;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.TextBox txtBookPrice;
        private System.Windows.Forms.TextBox txtBookZheKou;
        private System.Windows.Forms.TextBox txtBookSale;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtfukuan;
        private System.Windows.Forms.TextBox txtyingfu;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnJieZhang;
        private System.Windows.Forms.Button btnJiSuan;
        private System.Windows.Forms.TextBox txtReturn;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.RadioButton radbookID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radbookname;
    }
}