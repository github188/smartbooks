﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace 图书销售管理系统.图书销售管理
{
    public partial class DataEnvi : Form
    {
        public DataEnvi()
        {
            InitializeComponent();
        }

        

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            SqlConnection con = DB.CreateConnection();
            string strSql = "select*from bookrecord";
            SqlDataAdapter MyAdapter = new SqlDataAdapter(strSql, con);
            DataSet1 ds = new DataSet1();
            MyAdapter.Fill(ds, "bookrecord");
            //CrystalReport11.Load(Application.StartupPath + "\\" + "CrystalReport1.rpt");
            CrystalReport11.SetDataSource(ds);
            crystalReportViewer1.ReportSource = CrystalReport11;
            con.Dispose();
        }

      

    }
}