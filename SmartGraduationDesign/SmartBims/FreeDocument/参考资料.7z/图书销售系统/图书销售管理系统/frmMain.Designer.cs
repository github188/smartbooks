﻿namespace 图书销售管理系统
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.书库管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基本资料BToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书入库IToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书报表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书销售SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.价格维护PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售明细报表RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售报表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.账号管理ZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重新登陆CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于我们GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.退出EToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.记事本ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.计算器ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.水平平铺SToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.垂直排列CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.层叠排列DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.书库管理ToolStripMenuItem,
            this.销售管理ToolStripMenuItem,
            this.工具ToolStripMenuItem,
            this.系统管理ToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1021, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 书库管理ToolStripMenuItem
            // 
            this.书库管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本资料BToolStripMenuItem,
            this.图书入库IToolStripMenuItem,
            this.图书报表ToolStripMenuItem});
            this.书库管理ToolStripMenuItem.Name = "书库管理ToolStripMenuItem";
            this.书库管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.书库管理ToolStripMenuItem.Text = "书库管理";
            // 
            // 基本资料BToolStripMenuItem
            // 
            this.基本资料BToolStripMenuItem.Name = "基本资料BToolStripMenuItem";
            this.基本资料BToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.基本资料BToolStripMenuItem.Text = "基本资料(&B)";
            this.基本资料BToolStripMenuItem.Click += new System.EventHandler(this.基本资料BToolStripMenuItem_Click);
            // 
            // 图书入库IToolStripMenuItem
            // 
            this.图书入库IToolStripMenuItem.Name = "图书入库IToolStripMenuItem";
            this.图书入库IToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.图书入库IToolStripMenuItem.Text = "图书入库(&I)";
            this.图书入库IToolStripMenuItem.Click += new System.EventHandler(this.图书入库IToolStripMenuItem_Click);
            // 
            // 图书报表ToolStripMenuItem
            // 
            this.图书报表ToolStripMenuItem.Name = "图书报表ToolStripMenuItem";
            this.图书报表ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.图书报表ToolStripMenuItem.Text = "图书报表(&B)";
            this.图书报表ToolStripMenuItem.Click += new System.EventHandler(this.图书报表ToolStripMenuItem_Click);
            // 
            // 销售管理ToolStripMenuItem
            // 
            this.销售管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图书销售SToolStripMenuItem,
            this.价格维护PToolStripMenuItem,
            this.销售明细报表RToolStripMenuItem,
            this.销售报表ToolStripMenuItem});
            this.销售管理ToolStripMenuItem.Name = "销售管理ToolStripMenuItem";
            this.销售管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.销售管理ToolStripMenuItem.Text = "销售管理";
            // 
            // 图书销售SToolStripMenuItem
            // 
            this.图书销售SToolStripMenuItem.Name = "图书销售SToolStripMenuItem";
            this.图书销售SToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.图书销售SToolStripMenuItem.Text = "图书销售(&S)";
            this.图书销售SToolStripMenuItem.Click += new System.EventHandler(this.图书销售SToolStripMenuItem_Click);
            // 
            // 价格维护PToolStripMenuItem
            // 
            this.价格维护PToolStripMenuItem.Name = "价格维护PToolStripMenuItem";
            this.价格维护PToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.价格维护PToolStripMenuItem.Text = "价格维护(&P)";
            this.价格维护PToolStripMenuItem.Click += new System.EventHandler(this.价格维护PToolStripMenuItem_Click);
            // 
            // 销售明细报表RToolStripMenuItem
            // 
            this.销售明细报表RToolStripMenuItem.Name = "销售明细报表RToolStripMenuItem";
            this.销售明细报表RToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.销售明细报表RToolStripMenuItem.Text = "销售明细报表(&R)";
            this.销售明细报表RToolStripMenuItem.Click += new System.EventHandler(this.销售明细报表RToolStripMenuItem_Click);
            // 
            // 销售报表ToolStripMenuItem
            // 
            this.销售报表ToolStripMenuItem.Name = "销售报表ToolStripMenuItem";
            this.销售报表ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.销售报表ToolStripMenuItem.Text = "销售报表(N)";
            this.销售报表ToolStripMenuItem.Click += new System.EventHandler(this.销售报表ToolStripMenuItem_Click);
            // 
            // 系统管理ToolStripMenuItem
            // 
            this.系统管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.账号管理ZToolStripMenuItem,
            this.修改密码MToolStripMenuItem,
            this.重新登陆CToolStripMenuItem,
            this.关于我们GToolStripMenuItem,
            this.退出EToolStripMenuItem,
            this.toolStripMenuItem2,
            this.退出EToolStripMenuItem1});
            this.系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            this.系统管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.系统管理ToolStripMenuItem.Text = "系统管理";
            // 
            // 账号管理ZToolStripMenuItem
            // 
            this.账号管理ZToolStripMenuItem.Name = "账号管理ZToolStripMenuItem";
            this.账号管理ZToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.账号管理ZToolStripMenuItem.Text = "账号管理(&Z)";
            this.账号管理ZToolStripMenuItem.Click += new System.EventHandler(this.账号管理ZToolStripMenuItem_Click);
            // 
            // 修改密码MToolStripMenuItem
            // 
            this.修改密码MToolStripMenuItem.Name = "修改密码MToolStripMenuItem";
            this.修改密码MToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.修改密码MToolStripMenuItem.Text = "修改密码(&M)";
            this.修改密码MToolStripMenuItem.Click += new System.EventHandler(this.修改密码MToolStripMenuItem_Click);
            // 
            // 重新登陆CToolStripMenuItem
            // 
            this.重新登陆CToolStripMenuItem.Name = "重新登陆CToolStripMenuItem";
            this.重新登陆CToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.重新登陆CToolStripMenuItem.Text = "重新登陆(&C)";
            this.重新登陆CToolStripMenuItem.Click += new System.EventHandler(this.重新登陆CToolStripMenuItem_Click);
            // 
            // 关于我们GToolStripMenuItem
            // 
            this.关于我们GToolStripMenuItem.Name = "关于我们GToolStripMenuItem";
            this.关于我们GToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.关于我们GToolStripMenuItem.Text = "系统说明(&G)";
            this.关于我们GToolStripMenuItem.Click += new System.EventHandler(this.关于我们GToolStripMenuItem_Click);
            // 
            // 退出EToolStripMenuItem
            // 
            this.退出EToolStripMenuItem.Name = "退出EToolStripMenuItem";
            this.退出EToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.退出EToolStripMenuItem.Text = "给我写信(&O)";
            this.退出EToolStripMenuItem.Click += new System.EventHandler(this.退出EToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(149, 6);
            // 
            // 退出EToolStripMenuItem1
            // 
            this.退出EToolStripMenuItem1.Name = "退出EToolStripMenuItem1";
            this.退出EToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.退出EToolStripMenuItem1.Text = "退出(&E)";
            this.退出EToolStripMenuItem1.Click += new System.EventHandler(this.退出EToolStripMenuItem1_Click);
            // 
            // 工具ToolStripMenuItem
            // 
            this.工具ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.记事本ToolStripMenuItem1,
            this.计算器ToolStripMenuItem1});
            this.工具ToolStripMenuItem.Name = "工具ToolStripMenuItem";
            this.工具ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.工具ToolStripMenuItem.Text = "工具";
            // 
            // 记事本ToolStripMenuItem1
            // 
            this.记事本ToolStripMenuItem1.Name = "记事本ToolStripMenuItem1";
            this.记事本ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.记事本ToolStripMenuItem1.Text = "记事本";
            this.记事本ToolStripMenuItem1.Click += new System.EventHandler(this.记事本ToolStripMenuItem1_Click);
            // 
            // 计算器ToolStripMenuItem1
            // 
            this.计算器ToolStripMenuItem1.Name = "计算器ToolStripMenuItem1";
            this.计算器ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.计算器ToolStripMenuItem1.Text = "计算器";
            this.计算器ToolStripMenuItem1.Click += new System.EventHandler(this.计算器ToolStripMenuItem1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Silver;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripLabel2,
            this.toolStripLabel3,
            this.toolStripLabel4});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 677);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1021, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStripLabel1.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(112, 22);
            this.toolStripLabel1.Text = "toolStripLabel1";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStripLabel2.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(112, 22);
            this.toolStripLabel2.Text = "toolStripLabel2";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStripLabel3.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(112, 22);
            this.toolStripLabel3.Text = "toolStripLabel3";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStripLabel4.ForeColor = System.Drawing.Color.Black;
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(112, 22);
            this.toolStripLabel4.Text = "toolStripLabel4";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.水平平铺SToolStripMenuItem,
            this.垂直排列CToolStripMenuItem,
            this.层叠排列DToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(137, 70);
            // 
            // 水平平铺SToolStripMenuItem
            // 
            this.水平平铺SToolStripMenuItem.Name = "水平平铺SToolStripMenuItem";
            this.水平平铺SToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.水平平铺SToolStripMenuItem.Text = "水平平铺(&S)";
            this.水平平铺SToolStripMenuItem.Click += new System.EventHandler(this.水平平铺SToolStripMenuItem_Click);
            // 
            // 垂直排列CToolStripMenuItem
            // 
            this.垂直排列CToolStripMenuItem.Name = "垂直排列CToolStripMenuItem";
            this.垂直排列CToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.垂直排列CToolStripMenuItem.Text = "垂直排列(&C)";
            this.垂直排列CToolStripMenuItem.Click += new System.EventHandler(this.垂直排列CToolStripMenuItem_Click);
            // 
            // 层叠排列DToolStripMenuItem
            // 
            this.层叠排列DToolStripMenuItem.Name = "层叠排列DToolStripMenuItem";
            this.层叠排列DToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.层叠排列DToolStripMenuItem.Text = "层叠排列(&D)";
            this.层叠排列DToolStripMenuItem.Click += new System.EventHandler(this.层叠排列DToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1021, 702);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1029, 736);
            this.MinimumSize = new System.Drawing.Size(1022, 736);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "图书销售管理系统";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 书库管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基本资料BToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书入库IToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书报表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 销售管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书销售SToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 价格维护PToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 销售明细报表RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 销售报表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 账号管理ZToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码MToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重新登陆CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于我们GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出EToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 退出EToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 水平平铺SToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 垂直排列CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 层叠排列DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工具ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 记事本ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 计算器ToolStripMenuItem1;
    }
}