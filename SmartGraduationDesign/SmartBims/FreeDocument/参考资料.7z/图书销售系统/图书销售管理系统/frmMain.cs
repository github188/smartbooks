﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 图书销售管理系统
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

      
        ///
        ///打开子窗体，parentWindow为主窗口，childrenWindow为要打开的子窗体
        ///
        public static void openChildrenWindow(System.Windows.Forms.Form parentWindow, System.Windows.Forms.Form childrenWindow)
        {
            bool cwExists = false; //子窗体是否已经存在
            foreach (System.Windows.Forms.Form ff in parentWindow.MdiChildren)
            {
                //把活动的子窗体最小化
                ff.WindowState = System.Windows.Forms.FormWindowState.Minimized;
                //如果是要打开的子窗体，激活并还原子窗体
                if (ff.Name == childrenWindow.Name)
                {
                    ff.Activate();
                    //ff.Size = ff.Parent.Size;
                    ff.WindowState = System.Windows.Forms.FormWindowState.Normal;
                    ff.Left = ff.Top = 0; //打开位置居于左上角
                    cwExists = true; //子窗体存在
                }
            }
            //子窗体不存在，打开子窗体
            if (cwExists == false)
            {
                parentWindow.IsMdiContainer = true;
                childrenWindow.MdiParent = parentWindow;
                childrenWindow.WindowState = System.Windows.Forms.FormWindowState.Normal;
                childrenWindow.Show();
                childrenWindow.Left = childrenWindow.Top = 0; //打开位置居于左上角
            }
        }

      

        private void 退出EToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("mailto:zksfxy@126.com");
        
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
          
            
            //重新登陆CToolStripMenuItem.Enabled = false;
          
            show ss = new show();
            toolStripLabel1.Text = ss.caozuotest;
            toolStripLabel1.Text ="操作员账号:"+ this.toolStripLabel1.Text;
            if (ss.caozuotest == "admin")
            {
                toolStripLabel2.Text = "|  权限:管理员";
                价格维护PToolStripMenuItem.Visible = true;
                账号管理ZToolStripMenuItem.Visible  = true;
                修改密码MToolStripMenuItem.Enabled = false;
             
            }
            else
            {
                toolStripLabel2.Text = "|  权限:普通用户";
                价格维护PToolStripMenuItem.Visible = false ;
                账号管理ZToolStripMenuItem.Visible  = false;
             
            }
            toolStripLabel3.Text = "|  当前日期:" + DateTime.Now.ToLongDateString();
            toolStripLabel4.Text = "|  当前时间:  " + DateTime.Now.ToLongTimeString();
            timer1.Enabled = true;
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripLabel4.Text = "|  当前时间:  " + DateTime.Now.ToLongTimeString();
        }

        private void 基本资料BToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.BookJiben frm = new 图书销售管理系统.图书销售管理.BookJiben();
            openChildrenWindow(this, frm);
        }

        private void 图书入库IToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.InRecord frm = new 图书销售管理系统.图书销售管理.InRecord();
            openChildrenWindow(this, frm);
        }

        private void 图书销售SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.BookSale frm = new 图书销售管理系统.图书销售管理.BookSale();
            openChildrenWindow(this, frm);
        }

        private void 价格维护PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.FrmPrice frm = new 图书销售管理系统.图书销售管理.FrmPrice();
            openChildrenWindow(this, frm);
        }

        private void 修改密码MToolStripMenuItem_Click(object sender, EventArgs e)
        {
            系统管理.frmEditPwd frm = new 图书销售管理系统.系统管理.frmEditPwd();
            openChildrenWindow(this, frm);
        }

        private void 账号管理ZToolStripMenuItem_Click(object sender, EventArgs e)
        {
            系统管理.FrmManger frm = new 图书销售管理系统.系统管理.FrmManger();
            openChildrenWindow(this, frm);
        }

        private void 重新登陆CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
            
        }

        private void 关于我们GToolStripMenuItem_Click(object sender, EventArgs e)
        {
            系统管理.Our frm = new 图书销售管理系统.系统管理.Our();
            openChildrenWindow(this, frm);
        }

        private void 图书报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.DataEnvi frm = new 图书销售管理系统.图书销售管理.DataEnvi();
            openChildrenWindow(this, frm);
        }

             
          
        

        private void 销售明细报表RToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.SaleDatia frm = new 图书销售管理系统.图书销售管理.SaleDatia();
            openChildrenWindow(this, frm);
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("您确定要退出该应用程序吗?", "图书销售管理系统", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
       
        

       

        private void 退出EToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

     

        private void 水平平铺SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (System.Windows.Forms.Form ff in this.MdiChildren)
                ff.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal);
        }

        private void 垂直排列CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (System.Windows.Forms.Form ff in this.MdiChildren)
                ff.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical);
        }

        private void 层叠排列DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (System.Windows.Forms.Form ff in this.MdiChildren)
                ff.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);
        }

        private void 销售报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书销售管理.BookSaleDetil frm = new 图书销售管理系统.图书销售管理.BookSaleDetil();
            openChildrenWindow(this, frm);
        }

        
        private void 记事本ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("notepad.exe");
        }

        private void 计算器ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
                System.Diagnostics.Process.Start("calc.exe");
        }

      

        
       


     

       

  

     
    }
}