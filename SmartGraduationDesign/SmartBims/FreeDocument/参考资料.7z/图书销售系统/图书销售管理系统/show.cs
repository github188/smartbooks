﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 图书销售管理系统
{
   public class show
    {
        public static string caozuo;

        public string caozuotest
        {
            get
            {
                return caozuo;
            }
            set
            {
                caozuo = value;
            }
        }
    }
}
