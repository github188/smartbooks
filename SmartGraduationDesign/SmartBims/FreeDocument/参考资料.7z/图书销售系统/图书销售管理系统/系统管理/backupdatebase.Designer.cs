﻿namespace 图书销售管理系统.系统管理
{
    partial class backupdatebase
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(backupdatebase));
            this.fBD = new System.Windows.Forms.FolderBrowserDialog();
            this.txtlujing = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnview = new System.Windows.Forms.Button();
            this.btnupback = new System.Windows.Forms.Button();
            this.btncancle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rradfile = new System.Windows.Forms.RadioButton();
            this.rradlog = new System.Windows.Forms.RadioButton();
            this.raddiff = new System.Windows.Forms.RadioButton();
            this.rradall = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtlujing
            // 
            this.txtlujing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtlujing.Location = new System.Drawing.Point(47, 95);
            this.txtlujing.Name = "txtlujing";
            this.txtlujing.Size = new System.Drawing.Size(161, 21);
            this.txtlujing.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(6, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "路径:";
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnview.Location = new System.Drawing.Point(225, 95);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(56, 23);
            this.btnview.TabIndex = 2;
            this.btnview.Text = "浏览";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnupback
            // 
            this.btnupback.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupback.Location = new System.Drawing.Point(83, 159);
            this.btnupback.Name = "btnupback";
            this.btnupback.Size = new System.Drawing.Size(58, 23);
            this.btnupback.TabIndex = 3;
            this.btnupback.Text = "备份";
            this.btnupback.UseVisualStyleBackColor = true;
            this.btnupback.Click += new System.EventHandler(this.btnupback_Click);
            // 
            // btncancle
            // 
            this.btncancle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncancle.Location = new System.Drawing.Point(212, 159);
            this.btncancle.Name = "btncancle";
            this.btncancle.Size = new System.Drawing.Size(56, 23);
            this.btncancle.TabIndex = 4;
            this.btncancle.Text = "取消";
            this.btncancle.UseVisualStyleBackColor = true;
            this.btncancle.Click += new System.EventHandler(this.btncancle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.rradfile);
            this.groupBox1.Controls.Add(this.rradlog);
            this.groupBox1.Controls.Add(this.raddiff);
            this.groupBox1.Controls.Add(this.rradall);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtlujing);
            this.groupBox1.Controls.Add(this.btnview);
            this.groupBox1.Location = new System.Drawing.Point(26, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 135);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据库备份";
            // 
            // rradfile
            // 
            this.rradfile.AutoSize = true;
            this.rradfile.Location = new System.Drawing.Point(171, 51);
            this.rradfile.Name = "rradfile";
            this.rradfile.Size = new System.Drawing.Size(95, 16);
            this.rradfile.TabIndex = 6;
            this.rradfile.TabStop = true;
            this.rradfile.Text = "文件和文件组";
            this.rradfile.UseVisualStyleBackColor = true;
            this.rradfile.CheckedChanged += new System.EventHandler(this.rradfile_CheckedChanged);
            // 
            // rradlog
            // 
            this.rradlog.AutoSize = true;
            this.rradlog.Location = new System.Drawing.Point(28, 52);
            this.rradlog.Name = "rradlog";
            this.rradlog.Size = new System.Drawing.Size(71, 16);
            this.rradlog.TabIndex = 5;
            this.rradlog.TabStop = true;
            this.rradlog.Text = "事务日志";
            this.rradlog.UseVisualStyleBackColor = true;
            this.rradlog.CheckedChanged += new System.EventHandler(this.rradlog_CheckedChanged);
            // 
            // raddiff
            // 
            this.raddiff.AutoSize = true;
            this.raddiff.Location = new System.Drawing.Point(171, 20);
            this.raddiff.Name = "raddiff";
            this.raddiff.Size = new System.Drawing.Size(101, 16);
            this.raddiff.TabIndex = 4;
            this.raddiff.TabStop = true;
            this.raddiff.Text = "数据库-(差异)";
            this.raddiff.UseVisualStyleBackColor = true;
            this.raddiff.CheckedChanged += new System.EventHandler(this.raddiff_CheckedChanged);
            // 
            // rradall
            // 
            this.rradall.AutoSize = true;
            this.rradall.Location = new System.Drawing.Point(28, 20);
            this.rradall.Name = "rradall";
            this.rradall.Size = new System.Drawing.Size(101, 16);
            this.rradall.TabIndex = 3;
            this.rradall.TabStop = true;
            this.rradall.Text = "数据库-(完全)";
            this.rradall.UseVisualStyleBackColor = true;
            this.rradall.CheckedChanged += new System.EventHandler(this.rradall_CheckedChanged);
            // 
            // backupdatebase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(356, 194);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btncancle);
            this.Controls.Add(this.btnupback);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "backupdatebase";
            this.Text = "备份数据库";
            this.Load += new System.EventHandler(this.backupdatebase_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog fBD;
        private System.Windows.Forms.TextBox txtlujing;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnupback;
        private System.Windows.Forms.Button btncancle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rradfile;
        private System.Windows.Forms.RadioButton rradlog;
        private System.Windows.Forms.RadioButton raddiff;
        private System.Windows.Forms.RadioButton rradall;
    }
}