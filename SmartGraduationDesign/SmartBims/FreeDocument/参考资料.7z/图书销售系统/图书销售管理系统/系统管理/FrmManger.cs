﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.系统管理
{
    public partial class FrmManger : Form
    {
        public FrmManger()
        {
            InitializeComponent();
        }
        private string Fetch()
        {
            SqlConnection con = DB.CreateConnection();
            con.Open();
            string str = "select 账号 from operator where 账号='" + textBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            string m = Convert.ToString(cmd.ExecuteScalar());
            con.Dispose();
            con.Close();
            cmd.Dispose();
            return m;
        }
        private void FrmManger_Load(object sender, EventArgs e)
        {
            btnalter.Enabled = button1.Enabled = false;
            string str = "select*from operator";
            DB db = new DB();
            DataSet ds = db.GetDataSet(str, "book");
            dgvOperatorManger.DataSource = ds.Tables["book"];
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("账号不允许为空", "账号管理");
                return;
            }
            if (Fetch() == "")
            {
                int m;
                if (checkBox1.Checked == true)
                {
                    m = 1;
                }
                else
                {
                    m = 0;
                }
                string str = "insert into operator values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "'," + m + ")";
                try
                {
                    DB.ExecCommand(str);
                    MessageBox.Show("添加成功", "提示");
                }
                catch
                {
                    MessageBox.Show("添加失败", "提示");
                }
                string str1 = "select*from operator";
                DB db = new DB();
                DataSet ds = db.GetDataSet(str1, "book");
                dgvOperatorManger.DataSource = ds.Tables["book"];
            }
            else
                MessageBox.Show("该账号已经存在,不能添加重复记录", "提示");
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            btnalter.Enabled =button1.Enabled= false;
            textBox1.Text = "";
            textBox1.Focus();
            textBox2.Text = "";
            textBox3.Text = "";
            checkBox1.Checked = false;
        }

        private void btnalter_Click(object sender, EventArgs e)
        {
            
            show ss=new show ();
            SqlConnection con = DB.CreateConnection();
            SqlDataAdapter MyAdapter = new SqlDataAdapter("select*from operator", con);
            SqlCommandBuilder cb = new SqlCommandBuilder(MyAdapter);
            DataSet ds = new DataSet();
            MyAdapter.Fill(ds, "book");
            dgvOperatorManger.DataSource = ds.Tables["book"];
            string str = textBox1.Text;
            DataColumn[] keys = new DataColumn[1];
            keys[0] = ds.Tables["book"].Columns["账号"];
            ds.Tables["book"].PrimaryKey = keys;
            object[] Find = new object[1];
            Find[0] = str;
            try
            {
                DataRow Row = ds.Tables["book"].Rows.Find(Find);
                if (Row != null)
                {
                    Row["账号"] = Convert.ToString(textBox1.Text);
                    Row["姓名"] = Convert.ToString(textBox2.Text);
                    Row["密码"] = Convert.ToString(textBox3.Text);
                    //int s;
                    if (checkBox1.Checked == true)
                    {
                        //s = 1;
                        Row["是否注销"] =1;
                    }
                    else
                    {
                         //s = 0;
                        Row["是否注销"] = 0;
                    }
                    MyAdapter.Update(ds, "book");
                    MessageBox.Show("修改成功", "提示");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("修改失败", "提示");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvOperatorManger_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnalter.Enabled = true;
            button1.Enabled = true;
            textBox1.Text = Convert.ToString(dgvOperatorManger["账号", dgvOperatorManger.CurrentCell.RowIndex].Value).Trim();
            textBox2.Text = Convert.ToString(dgvOperatorManger["姓名", dgvOperatorManger.CurrentCell.RowIndex].Value).Trim();
            textBox3.Text = Convert.ToString(dgvOperatorManger["密码", dgvOperatorManger.CurrentCell.RowIndex].Value).Trim();
            label5.Text = Convert.ToString(dgvOperatorManger["是否注销", dgvOperatorManger.CurrentCell.RowIndex].Value).Trim();
            if (label5.Text == "True")
                checkBox1.Checked = true;
            else
                checkBox1.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("一经删除,不得恢复,您确定要删除该用户吗?", "账号管理", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string str = "delete operator where 账号='" + textBox1.Text + "'";
                try
                {
                    DB.ExecCommand(str);
                    MessageBox.Show("数据删除成功!", "提示");
                }
                catch
                {
                    MessageBox.Show("数据删除失败,请重新操作", "提示");
                }
                string str1 = "select*from operator";
                DB db = new DB();
                DataSet ds = db.GetDataSet(str1, "book");
                dgvOperatorManger.DataSource = ds.Tables["book"];
            }
        }
    }
}