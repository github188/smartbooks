﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.系统管理
{
    public partial class backupdatebase : Form
    {
        public backupdatebase()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (fBD.ShowDialog() == DialogResult.OK)
                txtlujing.Text = fBD.SelectedPath;
        }

        private void btnupback_Click(object sender, EventArgs e)
        {
            string strsql="";
            if (rradall.Checked == true)
            {
                strsql = "exec proc_diskDevice @diskname='" + txtlujing.Text + "'";
            }
            if (raddiff.Checked == true)
            {
                strsql = "backup database 图书销售管理系统 to disk='" + txtlujing.Text + "' with differential,name='diff_salebook.bak'";
            }
            if (rradlog.Checked == true)
            {
                strsql = "backup log 图书销售管理系统 to disk='"+txtlujing.Text+"' with name='log_salebook.bak'";
            }
            if (rradfile.Checked == true)
            {
                //strsql="backup database 图书销售管理系统 file
            }
            try
            {
                DB.ExecCommand(strsql);
                if (rradall.Checked == true)
                {
                    MessageBox.Show("备份数据库成功", "备份数据库");
                }
                if (raddiff.Checked == true)
                {
                    MessageBox.Show("数据库差异备份成功", "差异备份");
                }
                if (rradlog.Checked == true)
                {
                    MessageBox.Show("事务日志备份成功", "事务日志");
                }

            }
            catch
            {
                if (rradall.Checked == true)
                {
                    MessageBox.Show("备份数据库失败,请稍后在试....", "备份数据库", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (raddiff.Checked == true)
                {
                    MessageBox.Show("差异备份失败,请稍后再试.....", "差异备份", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (rradlog.Checked == true)
                {
                    MessageBox.Show("事务日志备份失败,请稍后再试....", "事务日志", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btncancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rradall_CheckedChanged(object sender, EventArgs e)
        {
            if (rradall.Checked)
            {
                label1.Enabled = txtlujing.Enabled = btnview.Enabled = true;
                btnupback.Enabled = true;

            }
        }

        private void raddiff_CheckedChanged(object sender, EventArgs e)
        {
            
            if (raddiff.Checked)
            {
                label1.Enabled = txtlujing.Enabled = btnview.Enabled = true;
                btnupback.Enabled = true;
            }
        }

        private void rradlog_CheckedChanged(object sender, EventArgs e)
        {
            if (rradlog.Checked)
            {
                label1.Enabled = txtlujing.Enabled = btnview.Enabled = true;
                btnupback.Enabled = true;
            }
        }

        private void rradfile_CheckedChanged(object sender, EventArgs e)
        {
            if (rradfile.Checked)
            {
                label1.Enabled = txtlujing.Enabled = btnview.Enabled = true;
                btnupback.Enabled = true;
            }
        }

        private void backupdatebase_Load(object sender, EventArgs e)
        {
            label1.Enabled = txtlujing.Enabled = btnview.Enabled = false;
            btnupback.Enabled = false;
        }
    }
}