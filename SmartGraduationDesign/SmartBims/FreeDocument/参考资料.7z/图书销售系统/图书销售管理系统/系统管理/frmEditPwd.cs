﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 图书销售管理系统.系统管理
{
    public partial class frmEditPwd : Form
    {
        public frmEditPwd()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strsql;
            show ss=new show ();
            SqlConnection con = DB.CreateConnection();
            con.Open();
          strsql = "select 密码 from operator where 账号='" + ss.caozuotest + "'";
            SqlCommand cmd = new SqlCommand(strsql, con);
            string s = Convert.ToString(cmd.ExecuteScalar());
            if (s == textBox1.Text)
            {
                if (textBox2.Text == textBox3.Text)
                {
                    strsql = "update operator set 密码='" + textBox3.Text + "' where 账号='" + ss.caozuotest + "'";
                    try
                    {
                        DB.ExecCommand(strsql);
                        MessageBox.Show("密码修改成功!", "提示");
                        this.Close();
                    }
                    catch
                    {
                        MessageBox.Show("密码修改失败!", "提示");
                    }
                }
                else
                    MessageBox.Show("两次输入的新密码不一致,请重新输入!", "提示");
            }
            else
            {
                MessageBox.Show("旧密码输入错误,请重新输入!", "提示");
                textBox1.Text = "";
                textBox1.Focus();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}