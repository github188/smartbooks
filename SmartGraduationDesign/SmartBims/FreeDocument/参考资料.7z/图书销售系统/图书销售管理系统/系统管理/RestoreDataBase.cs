﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 图书销售管理系统.系统管理
{
    public partial class RestoreDataBase : Form
    {
        public RestoreDataBase()
        {
            InitializeComponent();
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            if (OFD.ShowDialog() == DialogResult.OK)
                txtOpen.Text = OFD.FileName;
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            string str="";
            if (radall.Checked == true)
            {
                str = "restore database 图书销售管理系统 from disk='" + txtOpen.Text + "' with file=1,norecovery";
            }
            if (radiff.Checked == true)
            {
                str = "restore database 图书销售管理系统 from disk='" + txtOpen.Text + "' with file=2,norecovery";
            }
            if (radlog.Checked == true)
            {
                str = "restore log 图书销售管理系统 from disk='" + txtOpen.Text + "' with file=3,recovery";
            }
            try
            {
                DB.ExecCommand(str);
                if (radall.Checked == true)
                {
                    MessageBox.Show("数据库恢复成功", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                if (radiff.Checked == true)
                {
                    MessageBox.Show("差异备份恢复成功", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                if (radlog.Checked == true)
                {
                    MessageBox.Show("事务日志恢复成功", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                if (radall.Checked == true)
                {
                    MessageBox.Show("数据恢复失败,请稍候在试", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (radiff.Checked == true)
                {
                    MessageBox.Show("差异备份恢复失败,请稍候在试", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (radlog.Checked == true)
                {
                    MessageBox.Show("事务日志恢复失败,请稍候在试", "恢复数据库", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void radall_CheckedChanged(object sender, EventArgs e)
        {
            if (radall.Checked)
            {
                txtOpen.Enabled = btnview.Enabled = btnback.Enabled = true;
            }
        }

        private void radiff_CheckedChanged(object sender, EventArgs e)
        {
            if (radiff.Checked)
            {
                txtOpen.Enabled = btnview.Enabled = btnback.Enabled = true;
            }
        }

        private void radlog_CheckedChanged(object sender, EventArgs e)
        {
            if (radlog.Checked)
            {
                txtOpen.Enabled = btnview.Enabled = btnback.Enabled = true;
            }
        }

        private void radfile_CheckedChanged(object sender, EventArgs e)
        {
            if (radfile.Checked)
            {
                txtOpen.Enabled = btnview.Enabled = btnback.Enabled = true;
            }
        }

        private void RestoreDataBase_Load(object sender, EventArgs e)
        {
            txtOpen.Enabled = btnview.Enabled = btnback.Enabled = false;
        }

        
    }
}