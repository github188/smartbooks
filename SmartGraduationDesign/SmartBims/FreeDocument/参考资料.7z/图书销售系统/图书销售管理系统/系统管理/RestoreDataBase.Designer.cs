﻿namespace 图书销售管理系统.系统管理
{
    partial class RestoreDataBase
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RestoreDataBase));
            this.txtOpen = new System.Windows.Forms.TextBox();
            this.btnview = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radfile = new System.Windows.Forms.RadioButton();
            this.radlog = new System.Windows.Forms.RadioButton();
            this.radiff = new System.Windows.Forms.RadioButton();
            this.radall = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOpen
            // 
            this.txtOpen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOpen.Location = new System.Drawing.Point(15, 75);
            this.txtOpen.Name = "txtOpen";
            this.txtOpen.Size = new System.Drawing.Size(209, 21);
            this.txtOpen.TabIndex = 0;
            // 
            // btnview
            // 
            this.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnview.Location = new System.Drawing.Point(241, 76);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(47, 20);
            this.btnview.TabIndex = 1;
            this.btnview.Text = "浏览";
            this.btnview.UseVisualStyleBackColor = true;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // btnback
            // 
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnback.Location = new System.Drawing.Point(62, 137);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(60, 23);
            this.btnback.TabIndex = 2;
            this.btnback.Text = "恢复";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancle.Location = new System.Drawing.Point(217, 137);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(57, 23);
            this.btnCancle.TabIndex = 3;
            this.btnCancle.Text = "取消";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // OFD
            // 
            this.OFD.FileName = "openFileDialog1";
            this.OFD.Filter = "所有文件(*.*)|*.*";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radfile);
            this.groupBox1.Controls.Add(this.radlog);
            this.groupBox1.Controls.Add(this.radiff);
            this.groupBox1.Controls.Add(this.radall);
            this.groupBox1.Controls.Add(this.txtOpen);
            this.groupBox1.Controls.Add(this.btnview);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(318, 109);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "恢复数据库";
            // 
            // radfile
            // 
            this.radfile.AutoSize = true;
            this.radfile.Location = new System.Drawing.Point(167, 50);
            this.radfile.Name = "radfile";
            this.radfile.Size = new System.Drawing.Size(95, 16);
            this.radfile.TabIndex = 5;
            this.radfile.TabStop = true;
            this.radfile.Text = "文件和文件组";
            this.radfile.UseVisualStyleBackColor = true;
            this.radfile.CheckedChanged += new System.EventHandler(this.radfile_CheckedChanged);
            // 
            // radlog
            // 
            this.radlog.AutoSize = true;
            this.radlog.Location = new System.Drawing.Point(27, 50);
            this.radlog.Name = "radlog";
            this.radlog.Size = new System.Drawing.Size(71, 16);
            this.radlog.TabIndex = 4;
            this.radlog.TabStop = true;
            this.radlog.Text = "事务日志";
            this.radlog.UseVisualStyleBackColor = true;
            this.radlog.CheckedChanged += new System.EventHandler(this.radlog_CheckedChanged);
            // 
            // radiff
            // 
            this.radiff.AutoSize = true;
            this.radiff.Location = new System.Drawing.Point(167, 20);
            this.radiff.Name = "radiff";
            this.radiff.Size = new System.Drawing.Size(101, 16);
            this.radiff.TabIndex = 3;
            this.radiff.TabStop = true;
            this.radiff.Text = "数据库-(差异)";
            this.radiff.UseVisualStyleBackColor = true;
            this.radiff.CheckedChanged += new System.EventHandler(this.radiff_CheckedChanged);
            // 
            // radall
            // 
            this.radall.AutoSize = true;
            this.radall.Location = new System.Drawing.Point(27, 20);
            this.radall.Name = "radall";
            this.radall.Size = new System.Drawing.Size(101, 16);
            this.radall.TabIndex = 2;
            this.radall.TabStop = true;
            this.radall.Text = "数据库-(完全)";
            this.radall.UseVisualStyleBackColor = true;
            this.radall.CheckedChanged += new System.EventHandler(this.radall_CheckedChanged);
            // 
            // RestoreDataBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 189);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCancle);
            this.Controls.Add(this.btnback);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RestoreDataBase";
            this.Text = "恢复数据库";
            this.Load += new System.EventHandler(this.RestoreDataBase_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtOpen;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radfile;
        private System.Windows.Forms.RadioButton radlog;
        private System.Windows.Forms.RadioButton radiff;
        private System.Windows.Forms.RadioButton radall;
    }
}